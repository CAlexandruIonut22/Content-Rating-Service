# app/llm_module/__init__.py
# Modul pentru integrarea modelului de limbaj